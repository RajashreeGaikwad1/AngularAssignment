import { Component, OnInit } from '@angular/core';
import{Item} from '../item';
@Component({
  selector: 'app-assignment2',
  templateUrl: './assignment2.component.html',
  styleUrls: ['./assignment2.component.css']
})
export class Assignment2Component implements OnInit {
  itemobj_array! :Item[];
  constructor() {
    this.itemobj_array=[
      {itemid:1,itemname:"mobile",price:12000},
      {itemid:2,itemname:"telivision",price:29000},
      {itemid:3,itemname:"refrigerator",price:26000}
     ]
  
   }

  ngOnInit(): void {
  }

}

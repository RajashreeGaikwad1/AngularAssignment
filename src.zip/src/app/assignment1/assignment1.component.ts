import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment1',
  templateUrl: './assignment1.component.html',
  styleUrls: ['./assignment1.component.css']
})
export class Assignment1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  msg:string = '';

  myfuction()
  {
var splitted = this.msg.split(","); 
console.log(splitted)
for (let i = 0; i < splitted.length; i++) {
  const element = splitted[i];
  document.write("\n"+element+"<br>");
  
}

  }
  
}

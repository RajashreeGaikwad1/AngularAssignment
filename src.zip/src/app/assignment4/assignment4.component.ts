import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-assignment4',
  templateUrl: './assignment4.component.html',
  styleUrls: ['./assignment4.component.css']
})
export class Assignment4Component implements OnInit {

  employeeinfo!:FormGroup
  listEmp!:any
  constructor(private fb :FormBuilder) { 

    this.listEmp=[];



    this.employeeinfo = this.fb.group({
      employeename: ['',Validators.required],
    employeeaddress:['',Validators.required],
    employeedepartment:['',Validators.required],
  })
  }
  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';
import { studentResult } from './studentResult';

@Component({
  selector: 'app-student-result',
  templateUrl: './student-result.component.html',
  styleUrls: ['./student-result.component.css']
})
export class StudentResultComponent implements OnInit {

  public results:studentResult[]=[
    new studentResult(1,"Rajashree",78),
    new studentResult(2,"Riya",29),
    new studentResult(3,"Shreya",59),
    new studentResult(4,"Rohi",70)
  ];
  constructor() { }

  ngOnInit(): void {
  }

}

export class Employee {
    employeename!:string;
    employeeaddress!:string;
    employeedepartment!:string;
}
